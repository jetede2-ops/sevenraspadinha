<?php
// SevenRaspadinha - config.php
define('ADMIN_USER', 'admin');
define('ADMIN_PASS_HASH', '$2y$10$JFtI8JDsCEV0cT9vFZ2yCeHBN14bBP3aJtRGkcRYktF3NYgduUmru'); // seven@adm2025
define('BALANCE_FILE', __DIR__.'/balance.json');
define('PIX_KEY_FILE', __DIR__.'/pixkey.json');
// PagHiper placeholders
define('PAGHIPER_API_KEY', 'apk_49869559-AylluNLZstilfBLZAjEhItVYIVklnxMJ');
define('PAGHIPER_TOKEN', 'LLGDPIJ4XSOL00TKG4W5YMNFXLTC3N30QLVERSXR26AP');
define('PAGHIPER_EMAIL', 'jetede2@gmail.com');
define('CALLBACK_URL', 'https://sevenraspadinha.com/api/pix-callback.php');
?>
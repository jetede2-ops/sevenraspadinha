<?php
require_once __DIR__.'/config.php';
session_start();
if(empty($_SESSION['admin_auth'])){ http_response_code(403); echo 'forbidden'; exit; }
$body = json_decode(file_get_contents('php://input'), true);
if(!$body || !isset($body['pix'])){ http_response_code(400); echo 'missing'; exit; }
file_put_contents(PIX_KEY_FILE, json_encode(['pix'=>$body['pix']]));
echo json_encode(['ok'=>true]);
?>
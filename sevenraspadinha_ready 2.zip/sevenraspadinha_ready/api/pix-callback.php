<?php
require_once __DIR__.'/config.php';
$raw = file_get_contents('php://input');
file_put_contents(__DIR__.'/pix_webhook.log', date('c').' '. $raw . PHP_EOL, FILE_APPEND);
$data = json_decode($raw, true);
if(!$data){ http_response_code(400); echo 'invalid'; exit; }
$status = $data['status'] ?? '';
$value_cents = $data['value_cents'] ?? null;
if(strtolower($status) === 'completed' || strtolower($status) === 'paid'){
    $amount = ($value_cents !== null) ? (float)$value_cents/100.0 : 0.0;
    if(!file_exists(BALANCE_FILE)) file_put_contents(BALANCE_FILE, json_encode(['balance'=>0.00]));
    $json = json_decode(file_get_contents(BALANCE_FILE), true);
    $json['balance'] = round((($json['balance'] ?? 0) + $amount), 2);
    file_put_contents(BALANCE_FILE, json_encode($json));
    file_put_contents(__DIR__.'/pix_log.txt', date('c').' +'.number_format($amount,2,'.','').PHP_EOL, FILE_APPEND);
}
echo 'OK';
?>
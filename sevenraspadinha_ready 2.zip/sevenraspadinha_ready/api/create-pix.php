<?php
require_once __DIR__.'/config.php';
header('Content-Type: application/json');
$valor = isset($_GET['valor']) ? (float)$_GET['valor'] : 5.00;
$order_id = uniqid('sr-');
$pix_string = "PIX_SIMULADO|order:{$order_id}|amount:".number_format($valor,2,'.','');
echo json_encode(['status'=>'ok','order_id'=>$order_id,'qrcode'=>'data:image/png;base64,'.base64_encode($pix_string),'pix_text'=>$pix_string]);
?>
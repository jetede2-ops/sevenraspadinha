<?php
require_once __DIR__.'/config.php';
session_start();
function getBalance(){ if(!file_exists(BALANCE_FILE)) file_put_contents(BALANCE_FILE, json_encode(['balance'=>0.00])); $j=json_decode(file_get_contents(BALANCE_FILE), true); return floatval($j['balance'] ?? 0.0); }
function setBalance($v){ file_put_contents(BALANCE_FILE, json_encode(['balance'=>round($v,2)])); }
function getPixKey(){ if(!file_exists(PIX_KEY_FILE)) return ''; $j=json_decode(file_get_contents(PIX_KEY_FILE), true); return $j['pix'] ?? ''; }
function setPixKey($k){ file_put_contents(PIX_KEY_FILE, json_encode(['pix'=>$k])); }
if(isset($_GET['action']) && $_GET['action']==='logout'){ session_destroy(); header('Location: admin.php'); exit; }
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['user'])){ if($_POST['user']===ADMIN_USER && password_verify($_POST['pass'], ADMIN_PASS_HASH)){ $_SESSION['admin_auth']=true; header('Location: admin.php'); exit; } else $error='Usuário ou senha incorretos'; }
if(empty($_SESSION['admin_auth'])){ ?>
<!doctype html><html><head><meta charset='utf-8'><title>Login</title></head><body><h2>Login Admin</h2><?php if(!empty($error)) echo '<p style="color:red">'.$error.'</p>';?><form method="post"><input name="user" placeholder="Usuário" /><input name="pass" type="password" placeholder="Senha" /><button>Entrar</button></form></body></html><?php exit; }
$msg='';
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['pix_key'])){ setPixKey(trim($_POST['pix_key'])); $msg='Chave Pix atualizada.'; }
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['withdraw_now'])){ $bal=getBalance(); $pix=getPixKey(); if($bal<=0){ $msg='Saldo insuficiente.'; } elseif(empty($pix)){ $msg='Cadastre uma chave Pix antes.'; } else { setBalance(0.00); $msg='Saque de R$'.number_format($bal,2,',','.').' enviado para '.$pix.' (simulado).'; file_put_contents(__DIR__.'/withdraws.log', date('c').' - '.$msg.PHP_EOL, FILE_APPEND); } }
?>
<!doctype html><html><head><meta charset='utf-8'><title>Painel Admin</title></head><body><h1>SevenRaspadinha - Admin</h1><p>Bem-vindo, <strong><?php echo ADMIN_USER;?></strong> | <a href="?action=logout">Sair</a></p><?php if(!empty($msg)) echo '<div style="background:#dfd;padding:10px;margin-bottom:8px">'.$msg.'</div>'; ?><div><h3>Saldo disponível</h3><p>R$ <?php echo number_format(getBalance(),2,',','.');?></p><form method="post"><input name="pix_key" placeholder="Chave Pix" value="<?php echo htmlspecialchars(getPixKey());?>" /><button type="submit">Salvar Chave Pix</button></form><form method="post" style="margin-top:12px;"><button name="withdraw_now" value="1">Sacar via Pix (simulado)</button></form></div></body></html>

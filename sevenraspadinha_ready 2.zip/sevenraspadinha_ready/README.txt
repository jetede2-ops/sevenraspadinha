SevenRaspadinha - README

1) Faça upload da pasta extraída para seu hosting (Hostinger).
2) Edite api/config.php e cole PAGHIPER_API_KEY e PAGHIPER_TOKEN quando quiser ativar Pix real.
3) Configure CALLBACK_URL em api/config.php para: https://SEUDOMINIO.com/api/pix-callback.php
4) Acesse painel admin em /api/admin.php (Usuário: admin / Senha: seven@adm2025)
5) Saque é simulado: botão apenas zera o saldo e registra log.
